数学トレーニング Pro — Android APKビルド用プロジェクト

このZIPはAPK本体ではなく、Android StudioでAPKをビルドするためのプロジェクトです。

ビルド手順:
1. PCにAndroid Studioをインストールします。
2. Android Studioでこのフォルダ（MathTrainingAndroid）を開きます。
3. Gradle同期が完了するまで待ちます。
4. メニュー Build > Build Bundle(s) / APK(s) > Build APK(s) を選択します。
5. 完了後、app/build/outputs/apk/debug/app-debug.apk が生成されます。
6. APKをAndroid端末に転送し、必要な場合は「この提供元からのアプリのインストール」を許可してインストールします。

要件:
- Android Studio / JDK 17対応の環境
- 初回ビルド時はGradleとAndroid Gradle Pluginの取得にインターネット接続が必要です。

アプリはWebView内で同梱のHTMLを表示します。問題生成などの機能はHTML側に含まれています。
学習記録はWebViewのブラウザストレージに保存されます。
